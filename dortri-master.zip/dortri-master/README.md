# dortri
tembak tri
kuatmlarat
git clone git-nya
